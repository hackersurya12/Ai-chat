(function () {
  'use strict';

  var FN_BASE = "https://dwxgrmahesmacnjfvegy.supabase.co/functions/v1";
  var FALLBACK = {
    appName: "AI Chat",
    logoUrl: "assets/logo.png",
    apkUrl: "",
    latestVersionName: "1.1.9",
    latestVersionCode: 10,
    contactEmail: "suryaarun5@gmail.com",
    contactPhone: "",
    contactAddress: "",
    plans: [
      { id: "pro_monthly", title: "Pro Monthly Special", description: "Unlock premium models and priority support.", amount: 1000, currency: "INR", durationDays: 31 },
      { id: "pro_yearly", title: "Pro Yearly", description: "Best value — 12 months of Pro.", amount: 199900, currency: "INR", durationDays: 365 }
    ]
  };

  var FEATURES = [
    { icon: "chat", title: "Ask Anything", desc: "Get instant answers, explanations, and creative help on any topic." },
    { icon: "write", title: "Writing Assistant", desc: "Draft emails, messages, notes, and improve your wording instantly." },
    { icon: "learn", title: "Learning & Study", desc: "Understand concepts, summarize text, practice languages, and more." },
    { icon: "translate", title: "Translation", desc: "Translate and converse in English, Tamil, and Tanglish (mixed)." },
    { icon: "voice", title: "Voice Conversation", desc: "Speak naturally — auto language detection, male voice replies." },
    { icon: "files", title: "File Attachments", desc: "Attach images or documents and ask questions about them." },
    { icon: "offline", title: "Works Offline", desc: "Core features work without internet; syncs when online." },
    { icon: "privacy", title: "Privacy First", desc: "No ads, no tracking. Your data stays on your device." },
    { icon: "premium", title: "Pro Plans", desc: "Optional premium for priority models and faster responses." }
  ];

  var FAQS = [
    { q: "Is AI Chat free to use?", a: "Yes, AI Chat has a free tier with daily usage limits. Optional premium plans unlock priority models and support." },
    { q: "How do I install the APK?", a: "Download the APK from this page, open it from your notifications or Files app, and allow installation from unknown sources when prompted. See the download section for step-by-step instructions." },
    { q: "What languages does it support?", a: "AI Chat supports English, Tamil, and Tanglish (mixed English-Tamil). The voice assistant auto-detects the language you speak." },
    { q: "Does the voice assistant use a female voice?", a: "No — the app uses a natural male voice for all spoken responses." },
    { q: "Are there automatic renewals for Pro plans?", a: "No. Pro plans run for their stated duration (31 or 365 days) and then end. There is no auto-renewal." },
    { q: "How do I get a refund?", a: "Contact us at suryaarun5@gmail.com with your account email and Razorpay payment/order reference. Refunds are processed per our policy." },
    { q: "Is my data private?", a: "Yes. Your chats stay on your device. We don't sell data or show ads. See our Privacy Policy for details." },
    { q: "What Android version is required?", a: "Android 8.0 (API 26) or higher." }
  ];

  var SCREENSHOTS = [
    "assets/screenshot1.png",
    "assets/screenshot2.png",
    "assets/screenshot3.png",
    "assets/screenshot4.png"
  ];

  function setText(id, value) {
    var el = document.getElementById(id);
    if (el && value) el.textContent = value;
  }

  function setHtml(id, value) {
    var el = document.getElementById(id);
    if (el && value) el.innerHTML = value;
  }

  function setAttr(id, attr, value) {
    var el = document.getElementById(id);
    if (el && value) el.setAttribute(attr, value);
  }

  function inr(amount) {
    return "\u20B9" + (amount / 100).toLocaleString("en-IN", { maximumFractionDigits: 2 });
  }

  function renderFeatures() {
    var host = document.getElementById("featuresGrid");
    if (!host) return;
    host.innerHTML = FEATURES.map(function (f) {
      var iconSvg = getFeatureIcon(f.icon);
      return '<article class="feature-card">' +
        '<div class="feature-icon">' + iconSvg + '</div>' +
        '<h3>' + f.title + '</h3>' +
        '<p>' + f.desc + '</p>' +
        '</article>';
    }).join('');
  }

  function getFeatureIcon(name) {
    var icons = {
      chat: '<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/></svg>',
      write: '<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a.996.996 0 0 0 0-1.41l-2.34-2.34a.996.996 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>',
      learn: '<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M12 3L1 9l11 6 9-4.91V17h2V9L12 3z"/></svg>',
      translate: '<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M12.87 15.07l-2.54 2.51.03.03A17.52 17.52 0 0 0 14 19.08V5h4v14.08a17.52 17.52 0 0 0-1.13-1.92l-.03-.03zM5 4.27L3.27 6 12 14.73V4.27H5zm19.73 10.46L20.73 18 12 9.27V18h7.73z"/></svg>',
      voice: '<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zM17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/></svg>',
      files: '<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/></svg>',
      offline: '<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2.59c.94 0 1.71.71 1.96 1.6l.21.24c.12.12.25.22.39.29.13.06.27.09.41.09.14 0 .27-.03.4-.09.14-.07.27-.17.38-.29l.24-.24c.09-.24.14-.51.14-.79V7c0-.55-.45-1-1-1H9c-.55 0-1 .45-1 1v11.93c0 .81-.59 1.49-1.32 1.69-.35.1-.71.15-1.07.15-.95 0-1.83-.43-2.45-1.09L3 12.53V21h8l2.54-6.54z"/></svg>',
      privacy: '<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M18 8h-1V7c0-2.76-2.24-5-5-5S7 4.24 7 7v1H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V7c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v1z"/></svg>',
      premium: '<svg viewBox="0 0 24 24" width="28" height="28"><path fill="currentColor" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>'
    };
    return icons[name] || icons.chat;
  }

  function renderPlans(plans) {
    var host = document.getElementById("plansGrid");
    if (!host || !plans || !plans.length) return;
    host.innerHTML = plans.map(function (p) {
      var isPopular = p.id === "pro_yearly";
      var period = p.durationDays === 31 ? "month" : "year";
      return '<article class="plan-card' + (isPopular ? ' popular' : '') + '">' +
        (isPopular ? '<span class="popular-badge">Best value</span>' : '') +
        '<h3>' + p.title + '</h3>' +
        '<div class="plan-price">' +
        '<span class="amount">' + inr(p.amount) + '</span>' +
        '<span class="period">/' + period + '</span>' +
        '</div>' +
        '<p class="plan-desc">' + p.description + '</p>' +
        '<ul class="plan-features">' +
        '<li>Priority AI models</li>' +
        '<li>Faster responses</li>' +
        '<li>Priority support</li>' +
        '<li>No daily limits</li>' +
        '</ul>' +
        '<a class="btn' + (isPopular ? ' primary' : ' ghost') + '" href="#download">Get Started</a>' +
        '</article>';
    }).join('');
  }

  function renderScreenshots() {
    var track = document.getElementById("screenshotTrack");
    var dots = document.getElementById("carouselDots");
    if (!track || !dots) return;

    track.innerHTML = SCREENSHOTS.map(function (src, i) {
      return '<div class="screenshot-slide' + (i === 0 ? ' active' : '') + '" style="background-image: url(' + src + ')"></div>';
    }).join('');

    dots.innerHTML = SCREENSHOTS.map(function (_, i) {
      return '<button class="carousel-dot' + (i === 0 ? ' active' : '') + '" data-index="' + i + '" aria-label="Screenshot ' + (i + 1) + '"></button>';
    }).join('');

    initCarousel();
  }

  var currentSlide = 0;
  function initCarousel() {
    var track = document.getElementById("screenshotTrack");
    var dots = document.getElementById("carouselDots");
    var prev = document.getElementById("carouselPrev");
    var next = document.getElementById("carouselNext");
    var total = SCREENSHOTS.length;
    if (!track || total <= 1) return;

    function goToSlide(index) {
      currentSlide = (index + total) % total;
      track.style.transform = 'translateX(-' + (currentSlide * 100) + '%)';
      dots.querySelectorAll('.carousel-dot').forEach(function (d, i) {
        d.classList.toggle('active', i === currentSlide);
      });
    }

    prev.addEventListener('click', function () { goToSlide(currentSlide - 1); });
    next.addEventListener('click', function () { goToSlide(currentSlide + 1); });
    dots.querySelectorAll('.carousel-dot').forEach(function (dot) {
      dot.addEventListener('click', function () { goToSlide(parseInt(dot.dataset.index, 10)); });
    });

    var autoPlay = setInterval(function () { goToSlide(currentSlide + 1); }, 5000);
    track.parentElement.addEventListener('mouseenter', function () { clearInterval(autoPlay); });
    track.parentElement.addEventListener('mouseleave', function () { autoPlay = setInterval(function () { goToSlide(currentSlide + 1); }, 5000); });
  }

  function renderFAQs() {
    var host = document.getElementById("faqGrid");
    if (!host) return;
    host.innerHTML = FAQS.map(function (f, i) {
      return '<details class="faq-item">' +
        '<summary>' + f.q + '</summary>' +
        '<p>' + f.a + '</p>' +
        '</details>';
    }).join('');
  }

  function applyConfig(cfg) {
    var logo = cfg.logoUrl || FALLBACK.logoUrl;
    Array.prototype.forEach.call(document.querySelectorAll("img.brand-logo, .hero-art img, .download-icon img"), function (img) {
      img.src = logo;
    });

    setText("biz-name", cfg.appName);
    setText("contact-biz", cfg.appName);

    var em = document.getElementById("contact-email");
    if (em) {
      em.textContent = cfg.contactEmail || "—";
      if (cfg.contactEmail) em.href = "mailto:" + cfg.contactEmail;
    }

    var link = document.getElementById("apk-download");
    var heroLink = document.getElementById("hero-download");
    var note = document.getElementById("downloadNote");
    var versionNote = document.getElementById("hero-version");

    if (link && cfg.apkUrl) {
      link.href = cfg.apkUrl;
      link.setAttribute("download", "");
    }
    if (heroLink && cfg.apkUrl) {
      heroLink.href = cfg.apkUrl;
      heroLink.setAttribute("download", "");
    }

    setText("dl-version", "Version " + (cfg.latestVersionName || FALLBACK.latestVersionName));
    setText("dl-date", "Updated " + new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }));

    if (note && cfg.latestVersionName) note.textContent = "Latest version " + cfg.latestVersionName + " — direct APK download.";
    if (versionNote && cfg.latestVersionName) versionNote.textContent = "v" + cfg.latestVersionName + " • " + (cfg.latestVersionCode ? 'Build ' + cfg.latestVersionCode : '') + " • " + new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

    renderPlans(cfg.plans);
    document.dispatchEvent(new CustomEvent("site-config", { detail: cfg }));
  }

  function boot() {
    var y = document.getElementById("year");
    if (y) y.textContent = String(new Date().getFullYear());

    renderFeatures();
    renderScreenshots();
    renderFAQs();

    initMobileNav();
    initSmoothScroll();
    initScrollAnimations();

    fetch(FN_BASE + "/storage-urls", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "publicConfig" })
    })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (cfg) { applyConfig(cfg || FALLBACK); })
      .catch(function () { applyConfig(FALLBACK); });
  }

  function initMobileNav() {
    var toggle = document.getElementById("navToggle");
    var nav = document.getElementById("nav");
    if (!toggle || !nav) return;

    toggle.addEventListener('click', function () {
      var expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', !expanded);
      nav.classList.toggle('open');
    });

    nav.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        var id = a.getAttribute('href');
        if (id === '#') return;
        var target = document.querySelector(id);
        if (target) {
          e.preventDefault();
          var header = document.getElementById('header');
          var offset = header ? header.offsetHeight : 0;
          var top = target.getBoundingClientRect().top + window.pageYOffset - offset;
          window.scrollTo({ top: top, behavior: 'smooth' });
        }
      });
    });
  }

  function initScrollAnimations() {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    document.querySelectorAll('.feature-card, .step-card, .plan-card, .faq-item, .contact-card, .section-header').forEach(function (el) {
      el.classList.add('fade-in');
      observer.observe(el);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();